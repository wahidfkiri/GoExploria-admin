<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    EditorController,
    TemplateController,
    OpenAIController,
    AuthController,
    GeminiController,
    HomeController,
    HomeV2Controller,
    LandingPageController,
    DestinationPageController
};

use App\Http\Controllers\Auth\SocialAuthController;
use App\Http\Controllers\Auth\AjaxAuthController;
use App\Http\Controllers\TemplateScraperController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Mail;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/chat', [ChatController::class, 'index'])->name('chat.index');
Route::post('/chat/send', [ChatController::class, 'sendMessage'])->name('chat.send');
Route::post('/chat/clear-history', [ChatController::class, 'clearHistory'])->name('chat.clear-history');
// Page de login
Route::get('/', [HomeV2Controller::class, 'index'])->name('home-v2');

Route::get('welcome-2', function () {
    return view('welcome');
});
Route::get('/map', function () {
    return view('home-v2.map');
})->name('home-v2.map');

// Nouvelle page d'accueil V2
Route::get('/home-v2', [HomeV2Controller::class, 'index'])->name('home-v2');

// Routes pour les pages de destinations
Route::prefix('destinations')->name('destinations.')->group(function () {
    Route::get('/', [DestinationPageController::class, 'index'])->name('index');
    Route::get('/continent/{slug}', [DestinationPageController::class, 'continent'])->name('continent');
    Route::get('/pays/{slug}', [DestinationPageController::class, 'country'])->name('country');
    Route::get('/province/{slug}', [DestinationPageController::class, 'province'])->name('province');
    Route::get('/region/{slug}', [DestinationPageController::class, 'region'])->name('region');
    Route::get('/ville/{slug}', [DestinationPageController::class, 'ville'])->name('ville');
    Route::get('/secteur/{slug}', [DestinationPageController::class, 'secteur'])->name('secteur');
});

// Landing Pages Routes
Route::prefix('landing')->name('landing.')->group(function () {
    Route::get('/experiences-quebec', [LandingPageController::class, 'experiencesQuebec'])->name('experiences-quebec');
    Route::get('/experiences-canada', [LandingPageController::class, 'experiencesCanada'])->name('experiences-canada');
    Route::get('/experiences-regional', [LandingPageController::class, 'experiencesRegional'])->name('experiences-regional');
    Route::get('/transport-aerien', [LandingPageController::class, 'transportAerien'])->name('transport-aerien');
    Route::get('/transport-terrestre', [LandingPageController::class, 'transportTerrestre'])->name('transport-terrestre');
    Route::get('/transport-maritime', [LandingPageController::class, 'transportMaritime'])->name('transport-maritime');
    Route::get('/hotels', [LandingPageController::class, 'hotels'])->name('hotels');
    Route::get('/auberges', [LandingPageController::class, 'auberges'])->name('auberges');
    Route::get('/locations', [LandingPageController::class, 'locations'])->name('locations');
    Route::get('/assurances', [LandingPageController::class, 'assurances'])->name('assurances');
    Route::get('/guides', [LandingPageController::class, 'guides'])->name('guides');
    Route::get('/urgences', [LandingPageController::class, 'urgences'])->name('urgences');
    Route::get('/promotions', [LandingPageController::class, 'promotions'])->name('promotions');
    Route::get('/explorer', [LandingPageController::class, 'explorer'])->name('explorer');
    Route::get('/destinations', [LandingPageController::class, 'destinations'])->name('destinations');
    Route::get('/certifications', [LandingPageController::class, 'certifications'])->name('certifications');
});

// Page de login
Route::get('/login', function () {
    return view('auth.login');
})->name('login');


// Route pour le dashboard (à protéger)
Route::get('/home', function () {
    return view('home');
})->name('home')->middleware('auth');

// Authentification Ajax
Route::post('/ajax-login', [AjaxAuthController::class, 'login'])->name('ajax.login');
Route::post('/ajax/register', [AuthController::class, 'ajaxRegister'])->name('ajax.register');
Route::get('/ajax-register', [AjaxAuthController::class, 'showRegisterForm'])->name('register');
// Routes d'authentification sociale
Route::get('/auth/google', [SocialAuthController::class, 'redirectToGoogle'])->name('auth.google');
Route::get('/auth/google/callback', [SocialAuthController::class, 'handleGoogleCallback']);
Route::get('/auth/facebook', [SocialAuthController::class, 'redirectToFacebook'])->name('auth.facebook');
Route::get('/auth/facebook/callback', [SocialAuthController::class, 'handleFacebookCallback']);

// Logout
Route::post('/logout', function () {
    Auth::logout();
    return redirect('/login');
})->name('logout');


// Éditeur (protégé)
Route::middleware(['auth','web','user.active'])->group(function () {


// Route pour le dashboard (à protéger)
Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');

    
    // Profil utilisateur
    Route::prefix('profile')->name('profile.')->group(function () {
        Route::get('/', [ProfileController::class, 'index'])->name('index');
        
        // Mise à jour des informations
        Route::put('/info', [ProfileController::class, 'updateInfo'])->name('update.info');
        Route::post('/avatar', [ProfileController::class, 'updateAvatar'])->name('update.avatar');
        
        // Sécurité
        Route::put('/password', [ProfileController::class, 'changePassword'])->name('change.password');
        Route::post('/2fa/toggle', [ProfileController::class, 'toggleTwoFactor'])->name('2fa.toggle');
        Route::delete('/sessions/{session}', [ProfileController::class, 'revokeSession'])->name('sessions.revoke');
        
        // Préférences
        Route::put('/preferences', [ProfileController::class, 'updatePreferences'])->name('update.preferences');
        
        // Notifications
        Route::put('/notifications', [ProfileController::class, 'updateNotifications'])->name('update.notifications');
        
        // Activités
        Route::get('/activities', [ProfileController::class, 'getActivities'])->name('activities');
    });


// Template scraping routes
Route::prefix('/scrape/templates')->group(function () {
    Route::get('/', [TemplateScraperController::class, 'index'])->name('templates.index');
    Route::get('/create', [TemplateScraperController::class, 'create'])->name('templates.create');
    Route::post('/', [TemplateScraperController::class, 'store'])->name('scrape.templates.store');
    Route::get('/{template}', [TemplateScraperController::class, 'show'])->name('templates.show');
    Route::get('/{template}/edit', [TemplateScraperController::class, 'edit'])->name('templates.edit');
    Route::put('/{template}', [TemplateScraperController::class, 'update'])->name('templates.update');
    Route::delete('/{template}', [TemplateScraperController::class, 'destroy'])->name('templates.destroy');
    Route::post('/scrape-now', [TemplateScraperController::class, 'scrapeNow'])->name('templates.scrape-now');
    Route::get('/{template}/preview', [TemplateScraperController::class, 'preview'])->name('templates.preview');
    Route::get('/{template}/raw-html', [TemplateScraperController::class, 'rawHtml'])->name('templates.raw-html');
    Route::get('/{template}/raw-css', [TemplateScraperController::class, 'rawCss'])->name('templates.raw-css');
});

// API Routes
Route::prefix('api')->group(function () {
    Route::get('/templates', [TemplateScraperController::class, 'apiIndex']);
    Route::post('/templates/scrape', [TemplateScraperController::class, 'apiScrape']);
    Route::get('/templates/{template}', [TemplateScraperController::class, 'apiShow']);
});

// Batch scraping route
Route::post('/batch-scrape', [TemplateScraperController::class, 'batchScrape'])->name('batch.scrape');



// routes/web.php ou routes/api.php

// routes/web.php
Route::get('/gemini/generate', [GeminiController::class, 'generate'])->name('gemini.generate');
Route::get('/gemini/test', [GeminiController::class, 'test'])->name('gemini.test');
});

// API Routes (protégées par Sanctum)
Route::prefix('api')->group(function () {
    
    // Routes publiques
    Route::post('/auth/login', [AuthController::class, 'apiLogin']);
    Route::post('/auth/register', [AuthController::class, 'apiRegister']);
    Route::get('/status', function () {
        return response()->json([
            'status' => 'online',
            'version' => '1.0.0',
            'timestamp' => now()
        ]);
    });
    
    // Routes API Destinations (publiques)
    Route::prefix('v1/destinations')->group(function () {
        Route::get('/continents', [App\Http\Controllers\Api\DestinationController::class, 'continents']);
        Route::get('/continents/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'continent']);
        Route::get('/countries', [App\Http\Controllers\Api\DestinationController::class, 'countries']);
        Route::get('/countries/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'country']);
        Route::get('/provinces', [App\Http\Controllers\Api\DestinationController::class, 'provinces']);
        Route::get('/provinces/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'province']);
        Route::get('/regions', [App\Http\Controllers\Api\DestinationController::class, 'regions']);
        Route::get('/regions/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'region']);
        Route::get('/villes', [App\Http\Controllers\Api\DestinationController::class, 'villes']);
        Route::get('/villes/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'ville']);
        Route::get('/secteurs', [App\Http\Controllers\Api\DestinationController::class, 'secteurs']);
        Route::get('/secteurs/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'secteur']);
        Route::get('/search', [App\Http\Controllers\Api\DestinationController::class, 'search']);
        Route::get('/hierarchy/{type}/{identifier}', [App\Http\Controllers\Api\DestinationController::class, 'hierarchy']);
    });
    
    // Routes API Map Points (publiques)
    Route::prefix('v1/map-points')->group(function () {
        Route::get('/', [App\Http\Controllers\Api\MapPointController::class, 'index']);
        Route::get('/{id}', [App\Http\Controllers\Api\MapPointController::class, 'show']);
        Route::get('/search', [App\Http\Controllers\Api\MapPointController::class, 'search']);
        Route::get('/categories', [App\Http\Controllers\Api\MapPointController::class, 'categories']);
        Route::get('/villes', [App\Http\Controllers\Api\MapPointController::class, 'villes']);
    });
    
    // Routes démo (limitées)
    Route::prefix('demo')->group(function () {
        Route::post('/ai/generate', [OpenAIController::class, 'demoGenerate'])
            ->middleware('throttle:5,1440'); // 5 requêtes par jour
            
        Route::get('/templates', [TemplateController::class, 'demoTemplates']);
    });
    
    // Routes authentifiées
    Route::middleware('auth:sanctum')->group(function () {
        
        // User info
        Route::get('/user', function () {
            return response()->json([
                'user' => auth()->user(),
                'token' => auth()->user()->currentAccessToken()
            ]);
        });
        
        Route::post('/auth/logout', [AuthController::class, 'apiLogout']);
        
        // Templates CRUD
        Route::apiResource('templates', TemplateController::class);
        Route::get('/templates/{id}/preview', [TemplateController::class, 'preview'])->name('templates.preview');
        Route::get('/templates/search/{query}', [TemplateController::class, 'search']);
        Route::post('/templates/{id}/clone', [TemplateController::class, 'clone']);
        
        // OpenAI Routes
        Route::prefix('ai')->group(function () {
            Route::post('/generate', [OpenAIController::class, 'generate'])
                ->middleware('throttle:30,1'); // 30 requêtes par minute
                
            Route::post('/optimize', [OpenAIController::class, 'optimize']);
            Route::post('/chat', [OpenAIController::class, 'chat'])
                ->middleware('throttle:60,1');
                
            Route::post('/code', [OpenAIController::class, 'code']);
            Route::post('/variations', [OpenAIController::class, 'variations']);
            Route::post('/improve', [OpenAIController::class, 'improve']);
            Route::get('/models', [OpenAIController::class, 'models']);
            Route::get('/usage', [OpenAIController::class, 'usage']);
            Route::get('/usage/stats', [OpenAIController::class, 'usageStats']);
            Route::get('/status', [OpenAIController::class, 'status']);
        });
    });

 
});

// Routes de santé
Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'timestamp' => now(),
        'services' => [
            'laravel' => app()->version(),
            'php' => PHP_VERSION,
            'database' => DB::connection()->getPdo() ? 'connected' : 'disconnected'
        ]
    ]);
});





Route::prefix('pages')->name('pages.')->group(function () {
    Route::get('/video-player', function() {
        return view('home-v2.pages.video-player');
    })->name('video-player');

    Route::get('/accord-mets-vins', function() {
        return view('home-v2.pages.accord-mets-vins');
    })->name('accord-mets-vins');
});