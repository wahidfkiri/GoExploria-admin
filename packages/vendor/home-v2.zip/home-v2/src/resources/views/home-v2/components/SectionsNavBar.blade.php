{{-- Barre de navigation horizontale — liens vers les principales sections --}}
<nav class="snb-bar" id="sectionsNavBar" aria-label="Navigation sections">
    <div class="snb-inner">
        <ul class="snb-links">
            <li>
                <a href="#section-medias" class="snb-link">
                    <i class="fas fa-photo-video"></i>
                    <span>Espaces Médias</span>
                </a>
            </li>
            <li>
                <a href="#section-next-level" class="snb-link">
                    <i class="fas fa-level-up-alt"></i>
                    <span>Next Level</span>
                </a>
            </li>
            <li>
                <a href="#section-restaurants" class="snb-link">
                    <i class="fas fa-utensils"></i>
                    <span>Restaurants &amp; Alimentations</span>
                </a>
            </li>
            <li>
                <a href="#section-vedettes" class="snb-link">
                    <i class="fas fa-star"></i>
                    <span>Espaces Vedettes</span>
                </a>
            </li>
            <li>
                <a href="#section-voyages" class="snb-link">
                    <i class="fas fa-plane-departure"></i>
                    <span>Voyages &amp; Forfaits</span>
                </a>
            </li>
            <li>
                <a href="#section-marketplace" class="snb-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Market Place</span>
                </a>
            </li>
            <li>
                <a href="#section-a-la-une" class="snb-link">
                    <i class="fas fa-newspaper"></i>
                    <span>&Agrave; la Une</span>
                </a>
            </li>
        </ul>
    </div>
</nav>
